import React from 'react';
import { createRoot } from 'react-dom/client';
import App from './App';

const ROOTS: Record<string, any> = {};

function mount(rootId = 'custom-checkout-root', props = {}) {
  const el = document.getElementById(rootId);
  if (!el) {
    console.warn(`[CustomCheckout] #${rootId} not found`);
    return;
  }

  if (ROOTS[rootId]) {
    ROOTS[rootId].render(<App {...props} />);
    return;
  }

  const root = createRoot(el);
  root.render(<App {...props} />);
  ROOTS[rootId] = root;
}

function unmount(rootId = 'custom-checkout-root') {
  if (ROOTS[rootId]) {
    ROOTS[rootId].unmount();
    delete ROOTS[rootId];
  }
}

(window as any).CustomCheckout = { mount, unmount };

export default mount;
