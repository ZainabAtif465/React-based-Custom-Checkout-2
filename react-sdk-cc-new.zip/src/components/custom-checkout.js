import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import App from "./App";

(window as any).CustomCheckout = {
  mount: (elementId: string, props?: any) => {
    const container = document.getElementById(elementId);
    if (!container) {
      console.error(`❌ Element #${elementId} not found`);
      return;
    }

    console.log("Mount called for", elementId);
    container.innerHTML = "<p style='color:red'>React mount function called!</p>";

    createRoot(container).render(
      <StrictMode>
        <App {...props} />
      </StrictMode>
    );

    console.log("✅ React render called");
  },
};
