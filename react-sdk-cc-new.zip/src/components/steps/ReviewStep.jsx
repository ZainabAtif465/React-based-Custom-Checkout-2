import React from "react";

export const ReviewStep = ({ prevStep, snapshot }) => {
  return (
    <div>
      <h2>Review Step</h2>
      <button onClick={prevStep}>Back</button>

      <pre
        style={{
          maxHeight: 200,
          overflow: "auto",
          background: "#111",
          color: "#eee",
          padding: 12,
          marginTop: 24,
        }}
      >
        {JSON.stringify(snapshot, null, 2)}
      </pre>
    </div>
  );
};
