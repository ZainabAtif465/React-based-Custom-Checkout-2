import React from "react";

export const ShippingStep = ({ nextStep }) => {
  return (
    <div>
      <h2>Shipping Step</h2>
      <button onClick={nextStep}>Next</button>
    </div>
  );
};
