import React from "react";

export const PaymentStep = ({ nextStep, prevStep }) => {
  return (
    <div>
      <h2>Payment Step</h2>
      <button onClick={prevStep}>Back</button>
      <button onClick={nextStep}>Next</button>
    </div>
  );
};
