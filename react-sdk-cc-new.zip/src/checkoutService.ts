import { createCheckoutService } from '@bigcommerce/checkout-sdk';

const checkoutService = createCheckoutService();

console.log('[CheckoutService] initialized');

export default checkoutService;
