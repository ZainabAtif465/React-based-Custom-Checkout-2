import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import "./index.css";
import App from "./App";

// Try BigCommerce first, fallback to Vite's local root
const container =
  document.getElementById("custom-checkout-root") ||
  document.getElementById("root");

if (container) {
  createRoot(container).render(
    <StrictMode>
      <App />
    </StrictMode>
  );
} else {
  console.error("❌ No mount container found (#custom-checkout-root or #root)");
}
