import { useEffect, useState } from "react";
import checkoutService from "./checkoutService";

// Step components (named exports ✅)
import { ShippingStep } from "./components/steps/ShippingStep";
import { PaymentStep as BillingStep } from "./components/steps/PaymentStep";
import { ReviewStep } from "./components/steps/ReviewStep";

export default function App() {
 

  const [snapshot, setSnapshot] = useState<any>(null);
  const [step, setStep] = useState(0);

  useEffect(() => {
    setSnapshot(checkoutService.getState());

    const unsubscribe = checkoutService.subscribe(() => {
      setSnapshot(checkoutService.getState());
    });

    // ⚠️ Replace with a real checkoutId
    checkoutService
      .loadCheckout("ccfa3bee-d057-4fc6-ac48-e3d74547d08c")
      .then(() => console.log("[CustomCheckout] Checkout loaded ✅"))
      .catch((err) =>
        console.error("[CustomCheckout] Error loading checkout ❌", err)
      );

    return () => unsubscribe();
  }, []);

  // Stepper flow
  const nextStep = () => setStep((s) => s + 1);
  const prevStep = () => setStep((s) => Math.max(0, s - 1));

  return (
    <main style={{ padding: 24, fontFamily: "sans-serif" }}>
      <h1>Custom Checkout</h1>

      {step === 0 && <ShippingStep nextStep={nextStep} />}
      {step === 1 && <BillingStep nextStep={nextStep} prevStep={prevStep} />}
      {step === 2 && <ReviewStep prevStep={prevStep} snapshot={snapshot} />}

      {/* Debug snapshot (optional) */}
      <pre
        style={{
          maxHeight: 200,
          overflow: "auto",
          background: "#111",
          color: "#eee",
          padding: 12,
          marginTop: 24,
        }}
      >
        {JSON.stringify(
          {
            cart: snapshot?.data?.getCart?.() || null,
            checkout: snapshot?.data?.getCheckout?.() || null,
          },
          null,
          2
        )}
      </pre>
    </main>
  );
}
