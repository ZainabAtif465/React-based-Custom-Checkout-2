import React, { useState } from "react";
import ShippingStep from "./ShippingStep";

const Checkout = () => {
  const [step, setStep] = useState(1);

  const nextStep = () => setStep(step + 1);

  return (
    <div className="checkout-container">
      {step === 1 && <ShippingStep nextStep={nextStep} />}

      {step === 2 && <div>Payment Step</div>}

      {step === 3 && <div>Review Step</div>}
    </div>
  );
};

export default Checkout;
