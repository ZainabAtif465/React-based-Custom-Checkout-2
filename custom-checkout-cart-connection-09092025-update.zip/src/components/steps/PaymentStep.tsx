import React, { useMemo, useState } from "react";
import checkoutService from "../../checkoutService";
 
type Props = { nextStep: () => void; prevStep: () => void };
 
export function PaymentStep({ nextStep, prevStep }: Props) {
  const sel: any = checkoutService.getState?.() || {};
  const methods = useMemo<any[]>(
    () => sel.data?.getPaymentMethods?.() || sel.getPaymentMethods?.() || [],
    [sel]
  );
 
  const fallbackId = (methods[0]?.id as string) || "offline";
  const [methodId, setMethodId] = useState<string>(fallbackId);
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState<string | null>(null);
 
  async function handleNext() {
    try {
      setErr(null);
      setLoading(true);
 
      console.log("Selected Payment Method:", methodId);
 
      // ✅ Initialize payment with the selected method
      await checkoutService.initializePayment({ methodId });
 
      // ✅ Proceed to review / order confirmation step
      nextStep();
    } catch (e: any) {
      setErr(e?.message || "Could not initialize payment");
    } finally {
      setLoading(false);
    }
  }
 
  return (
    <div>
      <h2>Payment Step</h2>
 
      {methods?.length ? (
        <div style={{ display: "grid", gap: 8, marginBottom: 12 }}>
          {methods.map((m: any) => (
            <label key={m.id} style={{ display: "flex", gap: 8, alignItems: "center" }}>
              <input
                type="radio"
                name="pm"
                checked={methodId === m.id}
                onChange={() => setMethodId(m.id)}
              />
              {m.id} {m.supportedCards ? `(${m.supportedCards.join(", ")})` : ""}
            </label>
          ))}
        </div>
      ) : (
        <div style={{ opacity: 0.8, marginBottom: 12 }}>
          No payment methods available — using "offline" fallback.
        </div>
      )}
 
      {err && <div style={{ color: "#ff6b6b", marginBottom: 8 }}>{err}</div>}
 
      <div style={{ display: "flex", gap: 8 }}>
        <button className="btn ghost" onClick={prevStep}>
          Back
        </button>
        <button className="btn primary" onClick={handleNext} disabled={loading}>
          {loading ? "Loading…" : "Next"}
        </button>
      </div>
    </div>
  );
}