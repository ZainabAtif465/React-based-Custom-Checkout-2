import React, { useMemo, useState, useEffect } from "react";
import checkoutService from "../../checkoutService";
import "./Shipping.css"; // Import the CSS file

type Props = { nextStep: () => void };

export function ShippingStep({ nextStep }: Props) {
  const sel = checkoutService.getState?.() || ({} as any);
  const pre = sel.getShippingAddress?.() || {};
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  const [form, setForm] = useState({
    firstName: pre.firstName || "",
    lastName: pre.lastName || "",
    email: pre.email || "",
    phone: pre.phone || "",
    address1: pre.address1 || "",
    city: pre.city || "",
    countryCode: pre.countryCode || "US",
    stateOrProvinceCode: pre.stateOrProvinceCode || "",
    postalCode: pre.postalCode || "",
  });

  const [countries, setCountries] = useState<any[]>([]);

  const options = useMemo(
    () => sel.getShippingOptions?.() || sel.data?.getShippingOptions?.() || [],
    [sel]
  );

  useEffect(() => {
    async function fetchCountries() {
      try {
        const response = await fetch("https://restcountries.com/v3.1/all");
        
        if (!response.ok) {
          throw new Error("Failed to fetch countries. Server returned a bad response.");
        }

        const data = await response.json();
        setCountries(data); 
      } catch (error) {
        setErr("Failed to load countries.");
        console.error("Error loading countries:", error);
      }
    }

    fetchCountries();
  }, []);

  function onChange(e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) {
    setForm({ ...form, [e.target.name]: e.target.value });
  }

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setErr(null);
    setSaving(true);

    try {
      await checkoutService.updateShippingAddress?.(form);
      nextStep();
    } catch (ex: any) {
      setErr(ex?.message || "Failed to save shipping address.");
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="shipping-container">
      <h2 className="section-title">Shipping Information</h2>

      <form onSubmit={onSubmit} className="form-container">
        <div className="grid-container">
          <input
            className="input-field"
            name="firstName"
            placeholder="First name"
            value={form.firstName}
            onChange={onChange}
          />
          <input
            className="input-field"
            name="lastName"
            placeholder="Last name"
            value={form.lastName}
            onChange={onChange}
          />
        </div>

        <div className="grid-container">
          <input
            className="input-field"
            name="email"
            placeholder="Email"
            type="email"
            value={form.email}
            onChange={onChange}
          />

          <input
            className="input-field"
            name="phone"
            placeholder="Phone"
            value={form.phone}
            onChange={onChange}
          />

          <input
            className="input-field"
            name="address1"
            placeholder="Address line 1"
            value={form.address1}
            onChange={onChange}
          />
        </div>

        <div className="grid-container">
          <input
            className="input-field"
            name="city"
            placeholder="City"
            value={form.city}
            onChange={onChange}
          />
          <input
            className="input-field"
            name="postalCode"
            placeholder="Postal code"
            value={form.postalCode}
            onChange={onChange}
          />
        </div>

        <div className="grid-container">
          <select
            className="input-field"
            name="countryCode"
            value={form.countryCode}
            onChange={onChange}
          >
            {Array.isArray(countries) && countries.length > 0 ? (
              countries.map((country: any) => (
                <option key={country.cca2} value={country.cca2}>
                  {country.name.official}
                </option>
              ))
            ) : (
              <option value="">No countries available</option>
            )}
          </select>
          <input
            className="input-field"
            name="stateOrProvinceCode"
            placeholder="State/Province code"
            value={form.stateOrProvinceCode}
            onChange={onChange}
          />
        </div>

        {err && <div className="error-message">{err}</div>}

        <button className="submit-button" disabled={saving}>
          {saving ? "Saving..." : "Next"}
        </button>
      </form>

      {options?.length ? (
        <div className="shipping-options">
          <strong>Available shipping options:</strong>
          <ul className="options-list">
            {options.map((o: any) => (
              <li key={o.id}>
                {o.description || o.type} — {o.cost?.formatted || o.cost?.value || ""}
              </li>
            ))}
          </ul>
        </div>
      ) : null}
    </div>
  );
}
