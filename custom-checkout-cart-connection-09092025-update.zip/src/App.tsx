import { useEffect, useState } from "react";
import { createCheckoutService } from "@bigcommerce/checkout-sdk";

import { ShippingStep } from "./components/steps/ShippingStep";
import { PaymentStep as BillingStep } from "./components/steps/PaymentStep";
import { ReviewStep } from "./components/steps/ReviewStep";

const checkoutService = createCheckoutService();

export default function App() {
  const [snapshot, setSnapshot] = useState<any>(null);
  const [toast, setToast] = useState<{ type: "ok" | "err"; msg: string } | null>(null);
  const [placing, setPlacing] = useState(false);

  const [currentStep, setCurrentStep] = useState(1);

  const translations = {
    cart: {
      continueShopping: "Click here to continue shopping",
      loginToCheckout: "Login to proceed to checkout",
      emptyCart: "Your cart is empty",
      checkout: "Proceed to checkout",
      items: "{NUM, plural, =0{(0 items)} one {(# item)} other {(# items)}}",
      subtotal: "Subtotal",
      shipping: "Shipping",
      grandTotal: "Grand total",
      enterCode: "Coupon code / Gift certificate",
      applyCoupon: "Apply coupon",
      giftWrapping: "Gift wrapping",
    },
    checkout: {
      title: "Checkout",
      address: "Shipping Address",
      button: "Check out",
      paymentMethod: "Payment Method",
      review: "Review",
    },
    footer: {
      text: "© {year} Your Store. All rights reserved.",
    },
  };

  async function ensureCheckoutId(): Promise<string | undefined> {
    let checkoutId = new URLSearchParams(window.location.search).get("checkoutId");
    if (checkoutId) return checkoutId;

    try {
      const res = await fetch("/api/storefront/carts", { credentials: "same-origin" });
      const carts = await res.json();
      if (!Array.isArray(carts) || carts.length === 0) return;

      const cartId = carts[0].id;
      checkoutId = cartId;

      const url = new URL(window.location.href);
      url.searchParams.set("checkoutId", checkoutId);
      window.history.replaceState({}, "", url);

      return checkoutId;
    } catch (err) {
      console.error("Error ensuring checkout:", err);
    }
  }

  useEffect(() => {
    (async () => {
      try {
        const cid = await ensureCheckoutId();
        if (!cid) {
          return setToast({ type: "err", msg: "No active cart found" });
        }

        await checkoutService.loadCheckout(cid);
        const state = checkoutService.getState();
        console.log("Loaded checkout data:", state); 
        setSnapshot(state);
      } catch (err) {
        console.error("Error loading checkout:", err);
        setToast({ type: "err", msg: "Failed to load checkout" });
      }
    })();
  }, []);

  async function placeOrder() {
    try {
      setPlacing(true);

      const methods = checkoutService.getState().data.getPaymentMethods() || [];
      if (!methods.length) throw new Error("No payment methods available");

      const methodId = methods[0].id;
      await checkoutService.initializePayment({ methodId });
      await checkoutService.submitOrder();

      setToast({ type: "ok", msg: "Order placed successfully 🎉" });
    } catch (e: any) {
      console.error("Place order error:", e);
      setToast({ type: "err", msg: e?.message || "Failed to place order" });
    } finally {
      setPlacing(false);
    }
  }

  const nextStep = () => {
    if (currentStep < 3) setCurrentStep((s) => s + 1);
  };
  const prevStep = () => {
    if (currentStep > 1) setCurrentStep((s) => s - 1);
  };

  const steps = ["Shipping", "Payment", "Review"];
  const Stepper = ({ current }: { current: number }) => (
    <div style={{ display: "flex", gap: 12, margin: "0 0 18px 0", flexWrap: "wrap" }}>
      {steps.map((label, i) => {
        const active = i + 1 === current;
        return (
          <div key={label} style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <div
              style={{
                width: 28,
                height: 28,
                borderRadius: "50%",
                display: "grid",
                placeItems: "center",
                border: "2px solid #223057",
                color: active ? "#0a1022" : "#9fb3d9",
                background: active ? "#6ea6ff" : "transparent",
                fontWeight: 700,
              }}
            >
              {i + 1}
            </div>
            <div style={{ color: active ? "#e9eefc" : "#9fb3d9", fontWeight: 600 }}>{label}</div>
            {i < steps.length - 1 && <span style={{ opacity: 0.35, margin: "0 6px" }}>›</span>}
          </div>
        );
      })}
    </div>
  );

  return (
    <div style={styles.container}>
      <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>

      <header style={styles.header}>
        <div style={styles.logo}>
          <a href="/" style={styles.logoLink}>
            {/* <img
              src="https://cdn.yourstore.com/logo.png"
              alt="Store Logo"
              style={styles.logoImage}
            /> */}
            <span style={styles.logoText}>Your Store</span>
            <h2 style={styles.headerText}>{translations.checkout.title}</h2>
          </a>
          
        </div>
      </header>

      {toast && (
        <div style={toast.type === "ok" ? styles.toastSuccess : styles.toastError}>{toast.msg}</div>
      )}

      <main style={styles.main}>
        <div style={styles.checkoutContainer}>
          <Stepper current={currentStep} />

          {currentStep === 1 && snapshot && (
            <ShippingStep
              checkoutService={checkoutService}
              snapshot={snapshot}
              nextStep={nextStep} 
            />
          )}

          {currentStep === 2 && snapshot && (
            <BillingStep
              checkoutService={checkoutService}
              snapshot={snapshot}
              nextStep={nextStep}
              prevStep={prevStep}
            />
          )}

          {currentStep === 3 && snapshot && <ReviewStep snapshot={snapshot} prevStep={prevStep} />}

          {!snapshot && <p style={styles.loadingText}>Loading checkout…</p>}
        </div>
      </main>

      <div
        style={{
          position: "sticky",
          bottom: 0,
          zIndex: 20,
          background: "rgba(9,13,29,.9)",
          borderTop: "1px solid #223057",
          backdropFilter: "blur(6px)",
        }}
      >
        <div
          style={{
            maxWidth: 1200,
            margin: "0 auto",
            padding: "14px 24px",
            display: "flex",
            gap: 12,
            justifyContent: "flex-end",
          }}
        >
          <button
            onClick={prevStep}
            disabled={currentStep === 1 || !snapshot}
            style={{
              background: "transparent",
              color: "#EAEAEA",
              border: "1px solid #223057",
              borderRadius: 12,
              padding: "10px 14px",
              fontWeight: 600,
              opacity: currentStep === 1 || !snapshot ? 0.6 : 1,
              cursor: currentStep === 1 || !snapshot ? "not-allowed" : "pointer",
            }}
          >
            Back
          </button>

          {currentStep < 3 ? (
            <button
              onClick={nextStep}
              disabled={!snapshot}
              style={{
                background: "#6ea6ff",
                color: "#0a1022",
                border: "none",
                borderRadius: 12,
                padding: "10px 14px",
                fontWeight: 700,
                cursor: !snapshot ? "not-allowed" : "pointer",
                opacity: !snapshot ? 0.6 : 1,
              }}
            >
              Next
            </button>
          ) : (
            <button
              onClick={placeOrder}
              disabled={placing || !snapshot}
              style={{
                background: "#6ea6ff",
                color: "#0a1022",
                border: "none",
                borderRadius: 12,
                padding: "10px 14px",
                fontWeight: 700,
                cursor: placing || !snapshot ? "not-allowed" : "pointer",
                opacity: placing || !snapshot ? 0.7 : 1,
                display: "inline-flex",
                alignItems: "center",
                gap: 8,
              }}
            >
              {placing && (
                <span
                  style={{
                    width: 14,
                    height: 14,
                    border: "2px solid rgba(0,0,0,.25)",
                    borderTopColor: "#0a1022",
                    borderRadius: "50%",
                    animation: "spin 1s linear infinite",
                  }}
                />
              )}
              Place Order
            </button>
          )}
        </div>
      </div>

      <footer style={styles.footer}>
        <p style={styles.footerText}>
          {translations.footer.text.replace("{year}", new Date().getFullYear().toString())}
        </p>
      </footer>
    </div>
  );
}

const styles = {
  container: {
    backgroundColor: '#121212',
    color: '#EAEAEA',
    maxWidth: '1200px',
    margin: '0 auto',
    padding: '40px',
    fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif",
  },
  header: {
    backgroundColor: '#1F1F1F',
    boxShadow: '0 2px 4px rgba(0, 0, 0, 0.2)',
    padding: '20px 40px',
    borderRadius: '8px',
    marginBottom: '30px',
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  logo: {
    display: 'flex',
    alignItems: 'center',
  },
  logoLink: {
    textDecoration: 'none',
    display: 'flex',
    alignItems: 'center',
    gap: '20px',
  },
  logoImage: {
    height: '50px',
    width: 'auto',
    marginRight: '10px',
  },
  logoText: {
    fontSize: '22px',
    fontWeight: 'bold',
    color: '#EAEAEA',
    
  },
  headerText: {
    fontSize: '26px',
    fontWeight: '600',
    color: '#EAEAEA',
    textAlign: 'center',
    marginTop: 0,  
  },
  toastSuccess: {
    padding: '12px 20px',
    margin: '20px auto',
    maxWidth: '600px',
    borderRadius: '8px',
    fontSize: '16px',
    fontWeight: '500',
    textAlign: 'center',
    backgroundColor: '#4CAF50',
    color: '#fff',
    border: '1px solid #388E3C',
  },
  toastError: {
    padding: '12px 20px',
    margin: '20px auto',
    maxWidth: '600px',
    borderRadius: '8px',
    fontSize: '16px',
    fontWeight: '500',
    textAlign: 'center',
    backgroundColor: '#F44336',
    color: '#fff',
    border: '1px solid #D32F2F',
  },
  main: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    padding: '40px 20px',
  },
  checkoutContainer: {
    backgroundColor: '#1F1F1F',
    padding: '24px',
    borderRadius: '16px',
    boxShadow: '0 4px 6px rgba(0, 0, 0, 0.2)',
    width: '100%',
    maxWidth: '900px',
    marginBottom: '40px',
  },
  step: {
    marginBottom: '30px',
  },
  loadingText: {
    fontSize: '18px',
    fontWeight: '500',
    color: '#EAEAEA',
  },
  buttonPrimary: {
    width: '100%',
    padding: '14px',
    borderRadius: '8px',
    fontSize: '18px',
    fontWeight: '600',
    cursor: 'pointer',
    backgroundColor: '#6366f1',
    color: 'white',
    transition: 'background-color 0.3s ease',
    border: 'none',
    marginTop: '20px',
  },
  buttonDisabled: {
    width: '100%',
    padding: '14px',
    borderRadius: '8px',
    fontSize: '18px',
    fontWeight: '600',
    cursor: 'not-allowed',
    backgroundColor: '#e5e7eb',
    color: '#9ca3af',
    border: 'none',
    marginTop: '20px',
  },
  footer: {
    backgroundColor: '#121212',
    padding: '20px 0',
    textAlign: 'center',
    fontSize: '14px',
    color: '#B0BEC5',
    marginTop: '40px',
  },
  footerText: {
    margin: '0',
  },
};
