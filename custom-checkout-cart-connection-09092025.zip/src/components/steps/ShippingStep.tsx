import React, { useMemo, useState } from "react";
import checkoutService from "../../checkoutService";
 
type Props = { nextStep: () => void };
 
export function ShippingStep({ nextStep }: Props) {
  const sel = checkoutService.getState?.() || ({} as any);
  const pre = sel.getShippingAddress?.() || {};
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState<string | null>(null);
 
  // Shipping form state initialization
  const [form, setForm] = useState({
    firstName: pre.firstName || "",
    lastName: pre.lastName || "",
    email: pre.email || "",
    phone: pre.phone || "",
    address1: pre.address1 || "",
    city: pre.city || "",
    countryCode: pre.countryCode || "US",
    stateOrProvinceCode: pre.stateOrProvinceCode || "",
    postalCode: pre.postalCode || "",
  });
 
  const options = useMemo(
    () => sel.getShippingOptions?.() || sel.data?.getShippingOptions?.() || [],
    [sel]
  );
 
  function onChange(e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) {
    setForm({ ...form, [e.target.name]: e.target.value });
  }
 
  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setErr(null);
    setSaving(true);
 
    try {
      await checkoutService.updateShippingAddress?.(form);
      nextStep();
    } catch (ex: any) {
      setErr(ex?.message || "Failed to save shipping address.");
    } finally {
      setSaving(false);
    }
  }
 
  return (
    <div>
      <h2 className="text-lg font-semibold text-gray-800 border-b pb-2 mb-4">
        Shipping Information
      </h2>
 
      <form onSubmit={onSubmit} className="space-y-4">
        {/* First & Last Name */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <input
            className="w-full border rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-indigo-500"
            name="firstName"
            placeholder="First name"
            value={form.firstName}
            onChange={onChange}
          />
          <input
            className="w-full border rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-indigo-500"
            name="lastName"
            placeholder="Last name"
            value={form.lastName}
            onChange={onChange}
          />
        </div>
 
        <input
          className="w-full border rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-indigo-500"
          name="email"
          placeholder="Email"
          type="email"
          value={form.email}
          onChange={onChange}
        />
 
        <input
          className="w-full border rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-indigo-500"
          name="phone"
          placeholder="Phone"
          value={form.phone}
          onChange={onChange}
        />
 
        <input
          className="w-full border rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-indigo-500"
          name="address1"
          placeholder="Address line 1"
          value={form.address1}
          onChange={onChange}
        />
 
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <input
            className="w-full border rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-indigo-500"
            name="city"
            placeholder="City"
            value={form.city}
            onChange={onChange}
          />
          <input
            className="w-full border rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-indigo-500"
            name="postalCode"
            placeholder="Postal code"
            value={form.postalCode}
            onChange={onChange}
          />
        </div>
 
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <select
            className="w-full border rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-indigo-500"
            name="countryCode"
            value={form.countryCode}
            onChange={onChange}
          >
            <option value="US">United States</option>
            <option value="CA">Canada</option>
          </select>
          <input
            className="w-full border rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-indigo-500"
            name="stateOrProvinceCode"
            placeholder="State/Province code"
            value={form.stateOrProvinceCode}
            onChange={onChange}
          />
        </div>
 
        {err && (
          <div className="text-sm text-red-600 bg-red-50 p-2 rounded border border-red-200">
            {err}
          </div>
        )}
 
        <button
          className="w-full bg-indigo-600 text-white py-2 px-4 rounded-lg font-medium hover:bg-indigo-700 transition disabled:opacity-50"
          disabled={saving}
        >
          {saving ? "Saving..." : "Next"}
        </button>
      </form>
 
      {options?.length ? (
        <div className="mt-6 text-sm">
          <strong className="text-gray-700">Available shipping options:</strong>
          <ul className="mt-2 list-disc list-inside space-y-1 text-gray-600">
            {options.map((o: any) => (
              <li key={o.id}>
                {o.description || o.type} —{" "}
                {o.cost?.formatted || o.cost?.value || ""}
              </li>
            ))}
          </ul>
        </div>
      ) : null}
    </div>
  );
}