import { createCheckoutService } from '@bigcommerce/checkout-sdk';
const checkoutService = createCheckoutService();
console.log('[CheckoutService] initialized');

export async function loadCheckout(cartId: string) {
  try {
    // Fetching the checkout data using the cartId
    const response = await fetch(`/api/storefront/checkout/${cartId}`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
      },
    });
    
    const data = await response.json();

    // Check if the cart and checkout data exists
    if (data?.cart && data?.checkout) {
      return data;
    } else {
      throw new Error('Cart or Checkout data missing');
    }
  } catch (error) {
    console.error('Error loading checkout:', error);
    throw error;
  }
}

export default checkoutService;
