import { useEffect, useState } from "react";
import { createCheckoutService } from "@bigcommerce/checkout-sdk";

// Step components
import { ShippingStep } from "./components/steps/ShippingStep";
import { PaymentStep as BillingStep } from "./components/steps/PaymentStep";
import { ReviewStep } from "./components/steps/ReviewStep";

const checkoutService = createCheckoutService();

export default function App() {
  const [snapshot, setSnapshot] = useState<any>(null);
  const [toast, setToast] = useState<{ type: "ok" | "err"; msg: string } | null>(null);
  const [placing, setPlacing] = useState(false);
  const [currentStep, setCurrentStep] = useState(1); // Track which step the user is on

  // Store translations
  const translations = {
    cart: {
      continueShopping: "Click here to continue shopping",
      loginToCheckout: "Login to proceed to checkout",
      emptyCart: "Your cart is empty",
      checkout: "Proceed to checkout",
      items: "{NUM, plural, =0{(0 items)} one {(# item)} other {(# items)}}",
      subtotal: "Subtotal",
      shipping: "Shipping",
      grandTotal: "Grand total",
      enterCode: "Coupon code / Gift certificate",
      applyCoupon: "Apply coupon",
      giftWrapping: "Gift wrapping",
    },
    checkout: {
      title: "Checkout",
      address: "Shipping Address",
      button: "Check out",
      paymentMethod: "Payment Method",
      review: "Review",
    },
    footer: {
      text: "© {year} Your Store. All rights reserved.",
    },
  };

  // ✅ Ensure checkout session (cart → checkout)
  async function ensureCheckoutId(): Promise<string | undefined> {
    let checkoutId = new URLSearchParams(window.location.search).get("checkoutId");
    if (checkoutId) return checkoutId;

    try {
      const res = await fetch("/api/storefront/carts", { credentials: "same-origin" });
      const carts = await res.json();
      if (!Array.isArray(carts) || carts.length === 0) return;

      const cartId = carts[0].id;
      checkoutId = cartId;

      const url = new URL(window.location.href);
      url.searchParams.set("checkoutId", checkoutId);
      window.history.replaceState({}, "", url);

      return checkoutId;
    } catch (err) {
      console.error("Error ensuring checkout:", err);
    }
  }

  // ✅ Load checkout data
  useEffect(() => {
    (async () => {
      try {
        const cid = await ensureCheckoutId();
        if (!cid) {
          return setToast({ type: "err", msg: "No active cart found" });
        }

        await checkoutService.loadCheckout(cid);
        const state = checkoutService.getState();
        console.log("Loaded checkout data:", state); // Log the state to verify data

        setSnapshot(state); // Set the snapshot with the fetched data
      } catch (err) {
        console.error("Error loading checkout:", err);
        setToast({ type: "err", msg: "Failed to load checkout" });
      }
    })();
  }, []);

  // ✅ Place Order
  async function placeOrder() {
    try {
      setPlacing(true);

      const methods = checkoutService.getState().data.getPaymentMethods() || [];
      if (!methods.length) throw new Error("No payment methods available");

      const methodId = methods[0].id;
      await checkoutService.initializePayment({ methodId });
      await checkoutService.submitOrder();

      setToast({ type: "ok", msg: "Order placed successfully 🎉" });
    } catch (e: any) {
      console.error("Place order error:", e);
      setToast({ type: "err", msg: e?.message || "Failed to place order" });
    } finally {
      setPlacing(false);
    }
  }

  // Go to the next step
  const nextStep = () => {
    if (currentStep < 3) {
      setCurrentStep(currentStep + 1);
    }
  };

  // Go back to the previous step
  const prevStep = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  return (
    <div style={styles.container}>
      {/* ✅ Header */}
      <header style={styles.header}>
        <div style={styles.logo}>
          <a href="/" style={styles.logoLink}>
            {/* <img
              src="https://cdn.yourstore.com/logo.png"
              alt="Store Logo"
              style={styles.logoImage}
            /> */}
            <span style={styles.logoText}>Your Store</span>
          </a>
          <h1 style={styles.headerText}>{translations.checkout.title}</h1>
        </div>
      </header>

      {/* ✅ Toast messages */}
      {toast && (
        <div style={toast.type === "ok" ? styles.toastSuccess : styles.toastError}>
          {toast.msg}
        </div>
      )}

      {/* ✅ Checkout Content */}
      <main style={styles.main}>
        {/* Shipping Step */}
        {currentStep === 1 && snapshot && (
          <ShippingStep
            checkoutService={checkoutService}
            snapshot={snapshot}
            nextStep={nextStep}
          />
        )}

        {/* Billing Step */}
        {currentStep === 2 && snapshot && (
          <BillingStep
            checkoutService={checkoutService}
            snapshot={snapshot}
            nextStep={nextStep}
            prevStep={prevStep}
          />
        )}

        {/* Review Step */}
        {currentStep === 3 && snapshot && (
          <ReviewStep snapshot={snapshot} prevStep={prevStep} />
        )}

        {/* Loading State */}
        {!snapshot && <p style={styles.loadingText}>Loading checkout…</p>}
      </main>

      {/* ✅ Footer */}
      <footer style={styles.footer}>
        <p style={styles.footerText}>
          {translations.footer.text.replace("{year}", new Date().getFullYear().toString())}
        </p>
      </footer>
    </div>
  );
}

// Inline styles with enhanced UI design
const styles = {
   container: {
    backgroundColor: '#121212',
    color: '#EAEAEA',
    maxWidth: '1200px',
    margin: '0 auto',
    padding: '40px',
    fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif",
  },
  header: {
    backgroundColor: '#1F1F1F',
    boxShadow: '0 2px 4px rgba(0, 0, 0, 0.2)',
    padding: '20px 40px',
    borderRadius: '8px',
    marginBottom: '30px',
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  logo: {
    display: 'flex',
    alignItems: 'center',
  },
  logoLink: {
    textDecoration: 'none',
    display: 'flex',
    alignItems: 'center',
  },
  logoImage: {
    height: '50px',
    width: 'auto',
    marginRight: '10px',
  },
  logoText: {
    fontSize: '22px',
    fontWeight: 'bold',
    color: '#EAEAEA',
  },
  headerText: {
    fontSize: '26px',
    fontWeight: '600',
    color: '#EAEAEA',
    textAlign: 'center',
    marginTop: '20px',
  },
  toastSuccess: {
    padding: '12px 20px',
    margin: '20px auto',
    maxWidth: '600px',
    borderRadius: '8px',
    fontSize: '16px',
    fontWeight: '500',
    textAlign: 'center',
    backgroundColor: '#4CAF50',
    color: '#fff',
    border: '1px solid #388E3C',
  },
  toastError: {
    padding: '12px 20px',
    margin: '20px auto',
    maxWidth: '600px',
    borderRadius: '8px',
    fontSize: '16px',
    fontWeight: '500',
    textAlign: 'center',
    backgroundColor: '#F44336',
    color: '#fff',
    border: '1px solid #D32F2F',
  },
  main: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    padding: '40px 20px',
  },
  checkoutContainer: {
    backgroundColor: '#1F1F1F',
    padding: '40px',
    borderRadius: '16px',
    boxShadow: '0 4px 6px rgba(0, 0, 0, 0.2)',
    width: '100%',
    maxWidth: '900px',
    marginBottom: '40px',
  },
  step: {
    marginBottom: '30px',
  },
  loadingText: {
    fontSize: '18px',
    fontWeight: '500',
    color: '#EAEAEA',
  },
  buttonPrimary: {
    width: '100%',
    padding: '14px',
    borderRadius: '8px',
    fontSize: '18px',
    fontWeight: '600',
    cursor: 'pointer',
    backgroundColor: '#6366f1',
    color: 'white',
    transition: 'background-color 0.3s ease',
    border: 'none',
    marginTop: '20px',
  },
  buttonDisabled: {
    width: '100%',
    padding: '14px',
    borderRadius: '8px',
    fontSize: '18px',
    fontWeight: '600',
    cursor: 'not-allowed',
    backgroundColor: '#e5e7eb',
    color: '#9ca3af',
    border: 'none',
    marginTop: '20px',
  },
  footer: {
    backgroundColor: '#121212',
    padding: '20px 0',
    textAlign: 'center',
    fontSize: '14px',
    color: '#B0BEC5',
    marginTop: '40px',
  },
  footerText: {
    margin: '0',
  },
};
