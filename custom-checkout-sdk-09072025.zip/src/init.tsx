import React from "react";
import { createRoot, Root } from "react-dom/client";
import App from "./App";

let root: Root | null = null;

function mountCheckout(containerId: string = "custom-checkout-root") {
  let el = document.getElementById(containerId);
  if (!el) {
    el = document.createElement("div");
    el.id = containerId;
    (document.querySelector("#main-content") || document.body).prepend(el);
  }
  if (!root) {
    root = createRoot(el);
  }
  root.render(<App />);
}

function unmountCheckout() {
  if (root) {
    root.unmount();
    root = null;
  }
}

// expose globally
(window as any).CustomCheckout = {
  mount: mountCheckout,
  unmount: unmountCheckout,
};

// auto-mount
if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", () => mountCheckout());
} else {
  mountCheckout();
}
