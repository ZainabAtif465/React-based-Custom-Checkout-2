// src/App.tsx
import React, { useEffect, useMemo, useState } from "react";
import checkoutService from "./checkoutService";

// Your step components (adjust paths if needed)
import { ShippingStep } from "./components/steps/ShippingStep";
import { PaymentStep as BillingStep } from "./components/steps/PaymentStep";
import { ReviewStep } from "./components/steps/ReviewStep";
// sab items ka count safe tarike se karega
const safeItemsCount = (cart: any) => {
  const lineItems = cart?.lineItems || {};
  const physical = lineItems.physicalItems || [];
  const digital = lineItems.digitalItems || [];
  const custom = lineItems.customItems || [];
  const gift = lineItems.giftCertificates || [];
  return physical.length + digital.length + custom.length + gift.length;
};

type Toast = { type: "ok" | "err"; msg: string } | null;

// --- Helper to always get a cartId ---
async function ensureCartId(): Promise<string | undefined> {
  let cartId = new URLSearchParams(window.location.search).get("cartId");

  if (!cartId) {
    const res = await fetch("/api/storefront/carts", { credentials: "same-origin" });
    const carts = await res.json();
    if (Array.isArray(carts) && carts.length > 0) {
      cartId = carts[0].id;
      // update URL without reload
      const url = new URL(window.location.href);
      url.searchParams.set("cartId", cartId);
      window.history.replaceState({}, "", url);
    }
  }
  return cartId ?? undefined;
}

export default function App() {
  const [snapshot, setSnapshot] = useState<any>(null); // checkout selectors/state
  const [step, setStep] = useState(0);
  const [loading, setLoading] = useState(true);
  const [placing, setPlacing] = useState(false);
  const [toast, setToast] = useState<Toast>(null);

  const steps = useMemo(() => ["Shipping", "Payment", "Review"], []);
  const selectors = snapshot || {};
  const cart = selectors?.getCart?.() || null;
  const checkout = selectors?.getCheckout?.() || null;

  // local Stepper
  const Stepper = ({ current }: { current: number }) => (
    <div style={{ display: "flex", gap: 12, marginBottom: 16, flexWrap: "wrap" }}>
      {steps.map((label, i) => (
        <div key={label} style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <div
            style={{
              width: 28,
              height: 28,
              borderRadius: "50%",
              display: "grid",
              placeItems: "center",
              border: "2px solid #223057",
              color: i === current ? "#0a1022" : "#9fb3d9",
              background: i === current ? "#6ea6ff" : "transparent",
              fontWeight: 700,
            }}
          >
            {i + 1}
          </div>
          <div style={{ color: i === current ? "#e9eefc" : "#9fb3d9", fontWeight: 600 }}>
            {label}
          </div>
          {i < steps.length - 1 && <span style={{ opacity: 0.35, margin: "0 6px" }}>›</span>}
        </div>
      ))}
    </div>
  );

  useEffect(() => {
    setSnapshot(checkoutService.getState());
    const unsubscribe = checkoutService.subscribe(() => {
      setSnapshot(checkoutService.getState());
    });

  (async () => {
    try {
      const cid = "5a90185c-3b6e-46ee-a263-f890814f52a3"; // 👈 yahan apna cartId daal diya
      await checkoutService.loadCheckout(cid);
      console.log("[CustomCheckout] Checkout loaded with", cid);
    } catch (e: any) {
      console.error("[CustomCheckout] load error", e);
      setToast({ type: "err", msg: e?.message || "Failed to load checkout" });
    } finally {
      setLoading(false);
    }
  })();


    return () => unsubscribe();
  }, []);

  const nextStep = () => setStep((s) => Math.min(s + 1, steps.length - 1));
  const prevStep = () => setStep((s) => Math.max(0, s - 1));

  async function placeOrder() {
    try {
      setPlacing(true);
      // TODO: change methodId to real gateway
      await checkoutService.initializePayment({ methodId: "offline" });
      await checkoutService.submitOrder();
      setToast({ type: "ok", msg: "Order placed 🎉" });
    } catch (e: any) {
      setToast({ type: "err", msg: e?.message || "Order failed" });
    } finally {
      setPlacing(false);
    }
  }

  if (loading) {
    return (
      <div
        style={{
          maxWidth: 1120,
          margin: "32px auto",
          color: "#e9eefc",
          fontFamily: "system-ui, sans-serif",
        }}
      >
        <div
          style={{
            padding: 20,
            borderRadius: 16,
            background: "#101a33",
            border: "1px solid #223057",
            display: "flex",
            alignItems: "center",
            gap: 12,
          }}
        >
          <div
            style={{
              width: 16,
              height: 16,
              border: "2px solid rgba(255,255,255,.25)",
              borderTopColor: "#fff",
              borderRadius: "50%",
              animation: "spin 1s linear infinite",
            }}
          />
          <div>Loading checkout…</div>
        </div>
        <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>
      </div>
    );
  }

  return (
    <>
      <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>

      {/* Header */}
      <div
        style={{
          position: "sticky",
          top: 0,
          zIndex: 20,
          background: "rgba(9,13,29,.85)",
          backdropFilter: "blur(8px)",
          borderBottom: "1px solid #223057",
        }}
      >
        <div
          style={{
            maxWidth: 1120,
            margin: "0 auto",
            padding: "14px 24px",
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            color: "#e9eefc",
            fontFamily: "system-ui, sans-serif",
          }}
        >
          <div style={{ fontWeight: 700, display: "flex", gap: 10, alignItems: "center" }}>
            <span>Custom Checkout</span>
          </div>
          <div style={{ fontSize: 12, color: "#9fb3d9" }}>
            Cart: {cart?.id ? String(cart.id).slice(0, 8) : "—"}
          </div>
        </div>
      </div>

      {/* Main grid */}
      <div
        style={{
          maxWidth: 1120,
          margin: "18px auto",
          padding: "0 24px",
          display: "grid",
          gridTemplateColumns: "1.3fr .7fr",
          gap: 20,
          fontFamily: "system-ui, sans-serif",
          color: "#e9eefc",
        }}
      >
        <section
          style={{
            background: "#101a33",
            border: "1px solid #223057",
            borderRadius: 16,
            padding: 20,
          }}
        >
          <Stepper current={step} />

          {step === 0 && <ShippingStep nextStep={nextStep} />}
          {step === 1 && <BillingStep nextStep={nextStep} prevStep={prevStep} />}
          {step === 2 && <ReviewStep prevStep={prevStep} snapshot={snapshot} />}
        </section>

        <aside
          style={{
            background: "#101a33",
            border: "1px solid #223057",
            borderRadius: 16,
            padding: 20,
          }}
        >
          <h3 style={{ marginTop: 0 }}>Order Summary</h3>
          <div style={{ display: "flex", justifyContent: "space-between", color: "#9fb3d9", margin: "8px 0" }}>
            <span>Items</span>
          <span>{cart ? safeItemsCount(cart) : 0}</span>
          </div>
          <div style={{ display: "flex", justifyContent: "space-between", color: "#9fb3d9", margin: "8px 0" }}>
            <span>Subtotal</span>
            <span>{checkout?.outstandingBalance?.toFixed?.(2) ?? "—"}</span>
          </div>
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              marginTop: 12,
              paddingTop: 10,
              borderTop: "1px dashed #223057",
              fontWeight: 800,
            }}
          >
            <span>Total Due</span>
            <span>
              {typeof cart?.cartAmount === "number"
                ? cart.cartAmount.toFixed(2)
                : "—"}
            </span>
          </div>
        </aside>
      </div>

      {/* Footer buttons */}
      <div
        style={{
          position: "sticky",
          bottom: 0,
          zIndex: 20,
          background: "rgba(9,13,29,.9)",
          borderTop: "1px solid #223057",
        }}
      >
        <div
          style={{
            maxWidth: 1120,
            margin: "0 auto",
            padding: "14px 24px",
            display: "flex",
            gap: 12,
            justifyContent: "flex-end",
          }}
        >
          <button
            onClick={prevStep}
            disabled={step === 0}
            style={{
              background: "transparent",
              color: "#e9eefc",
              border: "1px solid #223057",
              borderRadius: 12,
              padding: "10px 14px",
              fontWeight: 600,
              opacity: step === 0 ? 0.6 : 1,
              cursor: step === 0 ? "not-allowed" : "pointer",
            }}
          >
            Back
          </button>

          {step < steps.length - 1 ? (
            <button
              onClick={nextStep}
              style={{
                background: "#6ea6ff",
                color: "#0a1022",
                border: "none",
                borderRadius: 12,
                padding: "10px 14px",
                fontWeight: 700,
                cursor: "pointer",
              }}
            >
              Next
            </button>
          ) : (
            <button
              onClick={placeOrder}
              disabled={placing}
              style={{
                background: "#6ea6ff",
                color: "#0a1022",
                border: "none",
                borderRadius: 12,
                padding: "10px 14px",
                fontWeight: 700,
                cursor: placing ? "not-allowed" : "pointer",
                opacity: placing ? 0.7 : 1,
                display: "inline-flex",
                alignItems: "center",
                gap: 8,
              }}
            >
              {placing && (
                <span
                  style={{
                    width: 14,
                    height: 14,
                    border: "2px solid rgba(0,0,0,.25)",
                    borderTopColor: "#0a1022",
                    borderRadius: "50%",
                    animation: "spin 1s linear infinite",
                  }}
                />
              )}
              Place Order
            </button>
          )}
        </div>
      </div>

      {/* Toast */}
      {toast && (
        <div
          onClick={() => setToast(null)}
          style={{
            position: "fixed",
            right: 16,
            bottom: 16,
            background: "#121b34",
            border: `1px solid ${
              toast.type === "ok" ? "rgba(62,207,142,.5)" : "rgba(255,107,107,.45)"
            }`,
            padding: "12px 14px",
            borderRadius: 12,
            boxShadow: "0 10px 30px rgba(0,0,0,.35)",
            cursor: "pointer",
            color: "#e9eefc",
          }}
        >
          {toast.msg}
        </div>
      )}
    </>
  );
}
