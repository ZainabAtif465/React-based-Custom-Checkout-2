import React, { useMemo, useState } from "react";
import checkoutService from "../../checkoutService";

type Props = { nextStep: () => void };

export function ShippingStep({ nextStep }: Props) {
  const sel = checkoutService.getState?.() || ({} as any);
  const pre = sel.getShippingAddress?.() || {};
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  const [form, setForm] = useState({
    firstName: pre.firstName || "",
    lastName:  pre.lastName  || "",
    email:     pre.email     || "",
    phone:     pre.phone     || "",
    address1:  pre.address1  || "",
    city:      pre.city      || "",
    countryCode:           pre.countryCode || "US",
    stateOrProvinceCode:   pre.stateOrProvinceCode || "",
    postalCode:            pre.postalCode || "",
  });

  const options = useMemo(
    () => sel.getShippingOptions?.() || sel.data?.getShippingOptions?.() || [],
    [sel]
  );

  function onChange(e: React.ChangeEvent<HTMLInputElement|HTMLSelectElement>) {
    setForm({ ...form, [e.target.name]: e.target.value });
  }

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setErr(null); setSaving(true);
    try {
      await checkoutService.updateShippingAddress?.(form);
      nextStep();
    } catch (ex: any) {
      setErr(ex?.message || "Failed to save shipping");
    } finally { setSaving(false); }
  }

  return (
    <div>
      <h2>Shipping Step</h2>
      <form onSubmit={onSubmit} style={{display:"grid",gap:10,maxWidth:520}}>
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
          <input className="input" name="firstName" placeholder="First name" value={form.firstName} onChange={onChange}/>
          <input className="input" name="lastName"  placeholder="Last name"  value={form.lastName}  onChange={onChange}/>
        </div>
        <input className="input" name="email" placeholder="Email" value={form.email} onChange={onChange}/>
        <input className="input" name="phone" placeholder="Phone" value={form.phone} onChange={onChange}/>
        <input className="input" name="address1" placeholder="Address line 1" value={form.address1} onChange={onChange}/>
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
          <input className="input" name="city" placeholder="City" value={form.city} onChange={onChange}/>
          <input className="input" name="postalCode" placeholder="Postal code" value={form.postalCode} onChange={onChange}/>
        </div>
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
          <select className="input" name="countryCode" value={form.countryCode} onChange={onChange}>
            <option value="US">United States</option>
            <option value="CA">Canada</option>
          </select>
          <input className="input" name="stateOrProvinceCode" placeholder="State/Province code" value={form.stateOrProvinceCode} onChange={onChange}/>
        </div>

        {err && <div style={{color:"#ff6b6b"}}>{err}</div>}

        <button className="btn primary" disabled={saving}>
          {saving ? "Saving..." : "Next"}
        </button>
      </form>

      {options?.length ? (
        <div style={{marginTop:14,opacity:.85}}>
          <strong>Shipping options:</strong>
          <ul style={{marginTop:6}}>
            {options.map((o:any)=>(
              <li key={o.id}>{o.description || o.type} — {o.cost?.formatted || o.cost?.value || ""}</li>
            ))}
          </ul>
        </div>
      ) : null}
    </div>
  );
}
