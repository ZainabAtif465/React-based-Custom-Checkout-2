import React, { useState } from "react";
import ShippingStep from "./ShippingStep";
// You can later add PaymentStep, ReviewStep, etc.

const Checkout = () => {
  const [step, setStep] = useState(1);

  const nextStep = () => setStep(step + 1);

  return (
    <div className="checkout-container">
      {/* Step 1: Shipping */}
      {step === 1 && <ShippingStep nextStep={nextStep} />}

      {/* Step 2: Payment (placeholder) */}
      {step === 2 && <div>Payment Step</div>}

      {/* Step 3: Review (placeholder) */}
      {step === 3 && <div>Review Step</div>}
    </div>
  );
};

export default Checkout;
