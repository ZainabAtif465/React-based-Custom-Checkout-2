// src/main.tsx
// Use ONLY while running `npm run dev` to preview locally.
// Not included/used on the real BigCommerce checkout page.

import React from 'react';
import { createRoot } from 'react-dom/client';
import App from './App';

const el = document.getElementById('root');
if (el) {
  const root = createRoot(el);
  root.render(<App />);
}
