import React from "react";

type Props = { prevStep: () => void; snapshot: any };

export function ReviewStep({ prevStep, snapshot }: Props) {
  const sel = snapshot || {};
  const cart = sel.getCart?.() || sel.data?.getCart?.() || {};
  const checkout = sel.getCheckout?.() || sel.data?.getCheckout?.() || {};
  const items = cart?.lineItems?.physicalItems || [];
  console.log("ReviewStep Items:", items); 


  return (
    <div>
      <h2>Review Step</h2>

      <div style={{margin:"10px 0"}}>
        <strong>Items</strong>
        <ul>
          {items.map((it:any)=>(
            <li key={it.id}>
              {it.name} × {it.quantity} — {it.extendedSalePrice?.formatted || it.extendedSalePrice?.value}
            </li>
          ))}
          {!items.length && <li>(no items from API)</li>}
        </ul>
      </div>

      <div style={{display:"flex",justifyContent:"space-between",maxWidth:420}}>
        <div>Outstanding</div>
        <div>{checkout?.outstandingBalance?.formatted || checkout?.outstandingBalance?.toFixed?.(2) || "—"}</div>
      </div>

      <div style={{display:"flex",gap:8,marginTop:14}}>
        <button className="btn ghost" onClick={prevStep}>Back</button>
      </div>
    </div>
  );
}
