import { useEffect, useState } from "react";
import { createCheckoutService } from "@bigcommerce/checkout-sdk";

// Step components
import { ShippingStep } from "./components/steps/ShippingStep";
import { PaymentStep as BillingStep } from "./components/steps/PaymentStep";
import { ReviewStep } from "./components/steps/ReviewStep";

const checkoutService = createCheckoutService();

export default function App() {
  const [snapshot, setSnapshot] = useState<any>(null);
  const [toast, setToast] = useState<{ type: "ok" | "err"; msg: string } | null>(null);
  const [placing, setPlacing] = useState(false);

  // ✅ Ensure checkout session (cart → checkout)
  async function ensureCheckoutId(): Promise<string | undefined> {
    let checkoutId = new URLSearchParams(window.location.search).get("checkoutId");
    if (checkoutId) return checkoutId;

    try {
      // Get active cart
      const res = await fetch("/api/storefront/carts", { credentials: "same-origin" });
      const carts = await res.json();
      if (!Array.isArray(carts) || carts.length === 0) return;

      const cartId = carts[0].id;

      // Use cartId directly (Checkout SDK accepts it)
      checkoutId = cartId;

      // Save to URL for refreshes
      const url = new URL(window.location.href);
      url.searchParams.set("checkoutId", checkoutId);
      window.history.replaceState({}, "", url);

      return checkoutId;
    } catch (err) {
      console.error("Error ensuring checkout:", err);
    }
  }

  // ✅ Load checkout data
  useEffect(() => {
    (async () => {
      try {
        const cid = await ensureCheckoutId();
        if (!cid) return setToast({ type: "err", msg: "No active cart found" });

        await checkoutService.loadCheckout(cid);
        setSnapshot(checkoutService.getState());
      } catch (err) {
        console.error("Error loading checkout:", err);
        setToast({ type: "err", msg: "Failed to load checkout" });
      }
    })();
  }, []);

  // ✅ Place Order
  async function placeOrder() {
    try {
      setPlacing(true);

      const methods = checkoutService.getState().data.getPaymentMethods() || [];
      if (!methods.length) throw new Error("No payment methods available");

      const methodId = methods[0].id;
      await checkoutService.initializePayment({ methodId });
      await checkoutService.submitOrder();

      setToast({ type: "ok", msg: "Order placed successfully 🎉" });
    } catch (e: any) {
      console.error("Place order error:", e);
      setToast({ type: "err", msg: e?.message || "Failed to place order" });
    } finally {
      setPlacing(false);
    }
  }

  return (
    <div className="bg-white text-gray-900 min-h-screen flex flex-col">
      {/* ✅ Header */}
      <header className="shadow bg-white">
        <div className="flex items-center justify-between px-6 py-4">
          <h1 className="text-xl font-bold">Checkout</h1>
          <a href="/" className="flex items-center">
            <img src="https://cdn.yourstore.com/logo.png" alt="Store Logo" />

          </a>
        </div>
      </header>

      {/* ✅ Toast messages */}
      {toast && (
        <div
          className={`p-3 mx-6 mt-4 rounded-lg shadow text-sm font-medium ${
            toast.type === "ok"
              ? "bg-green-100 text-green-800 border border-green-300"
              : "bg-red-100 text-red-800 border border-red-300"
          }`}
        >
          {toast.msg}
        </div>
      )}

      {/* ✅ Checkout Content */}
      <main className="flex-1 px-6 py-8">
        {snapshot ? (
          <div className="space-y-8 max-w-3xl mx-auto bg-white p-6 rounded-xl shadow">
            <ShippingStep checkoutService={checkoutService} snapshot={snapshot} />
            <BillingStep checkoutService={checkoutService} snapshot={snapshot} />
            <ReviewStep snapshot={snapshot} />

            <button
              onClick={placeOrder}
              disabled={placing}
              className={`w-full py-3 rounded-lg font-semibold transition ${
                placing
                  ? "bg-gray-300 text-gray-600 cursor-not-allowed"
                  : "bg-indigo-600 text-white hover:bg-indigo-700"
              }`}
            >
              {placing ? "Placing order…" : "Place Order"}
            </button>
          </div>
        ) : (
          <p className="p-6 text-center text-gray-500">Loading checkout…</p>
        )}
      </main>

      {/* ✅ Footer */}
      <footer className="bg-white border-t mt-8">
        <p className="text-center p-4 text-sm text-gray-500">
          © {new Date().getFullYear()} Your Store. All rights reserved.
        </p>
      </footer>
    </div>
  );
}
