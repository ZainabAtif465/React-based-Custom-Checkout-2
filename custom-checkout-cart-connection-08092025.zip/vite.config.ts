import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  define: {
    'process.env.NODE_ENV': '"production"',
    'process.env': '{}',
    global: 'window',
  },
  build: {
    lib: {
      entry: 'src/init.tsx',
      name: 'CustomCheckout',
      formats: ['iife'],
      fileName: () => 'custom-checkout.iife.js',
    },
    rollupOptions: { output: { inlineDynamicImports: true } },
    sourcemap: true,
  },
})
