// src/App.tsx
import { useEffect, useState } from 'react';
import { checkoutService } from './checkoutService';

export default function App() {
  const [snapshot, setSnapshot] = useState<any>(null);

  useEffect(() => {
  // snapshot set karna
  setSnapshot(checkoutService.getState());

  // subscribe
  const unsubscribe = checkoutService.subscribe(() => {
    setSnapshot(checkoutService.getState());
  });

  // 👇 yahan apna checkoutId use karo (cartId se checkout banao aur id uthao)
  checkoutService.loadCheckout('j9sjssr8z5c03y8o9w7gcxlwglrj65d')
    .then(() => console.log('Checkout loaded!'))
    .catch(err => console.error('Error loading checkout:', err));

  return () => unsubscribe();
}, []);


  return (
    <main style={{ padding: 24, fontFamily: 'sans-serif' }}>
      <h1>Step 2 — SDK init test</h1>
      <p>Open the browser console to see logs from <code>checkoutService</code>.</p>

      <h3>Light snapshot (safe to render)</h3>
      <pre style={{ maxHeight: 300, overflow: 'auto', background: '#111', color: '#eee', padding: 12 }}>
        {JSON.stringify({
          isLoading: typeof snapshot?.isLoading === 'function' ? snapshot.isLoading() : undefined,
          getCart: typeof snapshot?.getCart === 'function' ? snapshot.getCart() : undefined,
          getCheckout: typeof snapshot?.getCheckout === 'function' ? snapshot.getCheckout() : undefined,
        }, null, 2)}
      </pre>

      <p>When you see `CheckoutService initialized` in console, this step worked.</p>
    </main>
  );
}
