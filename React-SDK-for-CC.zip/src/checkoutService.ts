import { createCheckoutService } from '@bigcommerce/checkout-sdk';
export const checkoutService = createCheckoutService();
