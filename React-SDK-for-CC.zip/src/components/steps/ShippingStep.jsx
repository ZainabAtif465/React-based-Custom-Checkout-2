import React from "react";

const ShippingStep = ({ nextStep }) => {
  return (
    <div className="checkout-step">
      <h2>Shipping Step</h2>
      <p>This is the first step of your custom checkout.</p>
      <button onClick={nextStep}>Next Step</button>
    </div>
  );
};

export default ShippingStep;
