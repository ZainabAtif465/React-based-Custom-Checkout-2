// 1️⃣ Import React and ReactDOM
import React from 'react';
import { createRoot } from 'react-dom/client';

// 2️⃣ Import your main Checkout component
import Checkout from './Checkout'; // Make sure the path is correct

// 3️⃣ Mount React app only if container exists
const container = document.getElementById('custom-checkout-root');
if (container) {
    const root = createRoot(container);
    // Render the main Checkout component
    root.render(<Checkout />);
}
